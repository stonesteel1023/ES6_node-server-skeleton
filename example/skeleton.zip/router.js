import express from "express";
//const homeRouter = require("Router");
import {root,handleHome, homeController} from "./controller";
//const homeController = require("./controller");

const homeRouter = express.Router();
homeRouter.get("/", root);
homeRouter.get("/home", handleHome);
homeRouter.get("/home/index", homeController);

export default homeRouter;