export const root = (req, res) => (res.send("Hello, World!"));
export const handleHome = (req, res) => (res.send("This is Home"));
export const homeController = (req, res) => (res.send("It is index"));