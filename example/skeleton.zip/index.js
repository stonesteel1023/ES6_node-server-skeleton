import express from "express";
//const express = require("express");
import homeRouter from "./router";
//const homeRouter = require("./router");

const PORT = 4000;

const handleLogin = () => {
    console.log(`Login`);
}

// const handleHome = (req, res) => {
//     res.send("Hi from home");
// }

// const handleRouter = (req, res) => {
//     res.send("This is home");
// }

const app = express();

//app.use("/", handleHome);
app.use("/", homeRouter);

app.listen(PORT, handleLogin);